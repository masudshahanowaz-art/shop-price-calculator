package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testMoneyToWeightCalculation() {
        val amount = 50.0 // ₹ 50
        val pricePerKg = 100.0 // ₹ 100 / kg
        val weightGrams = (amount * 1000.0) / pricePerKg
        assertEquals(500.0, weightGrams, 0.001)
    }

    @Test
    fun testWeightToMoneyCalculation() {
        val weightGrams = 250.0 // 250 g
        val pricePerKg = 80.0 // ₹ 80 / kg
        val price = (weightGrams * pricePerKg) / 1000.0
        assertEquals(20.0, price, 0.001)
    }
}
