package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Product
import com.example.data.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.DecimalFormat

class ShopCalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProductRepository

    val products: StateFlow<List<Product>>
    val selectedProductId = MutableStateFlow<Int?>(null)

    val selectedProduct: StateFlow<Product?>

    // Calculator Inputs
    val moneyInput = MutableStateFlow("")
    val weightInput = MutableStateFlow("")

    // Dialog state management
    val showAddEditDialog = MutableStateFlow(false)
    val productToEdit = MutableStateFlow<Product?>(null)

    val showDeleteDialog = MutableStateFlow(false)
    val productToDelete = MutableStateFlow<Product?>(null)

    // Form input state inside dialog
    val dialogNameInput = MutableStateFlow("")
    val dialogPriceInput = MutableStateFlow("")
    val dialogError = MutableStateFlow<String?>(null)

    private val currencyFormat = DecimalFormat("#,##0.00")
    private val decimalFormat = DecimalFormat("#,##0.##")

    init {
        val productDao = AppDatabase.getDatabase(application).productDao()
        repository = ProductRepository(productDao)

        products = repository.allProducts.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        selectedProduct = combine(products, selectedProductId) { productList, id ->
            if (productList.isEmpty()) {
                null
            } else if (id == null) {
                productList.firstOrNull()
            } else {
                productList.find { it.id == id } ?: productList.firstOrNull()
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

        // Prepopulate default items if database is empty
        viewModelScope.launch {
            if (repository.getProductCount() == 0) {
                val defaultProducts = listOf(
                    Product(name = "Rice (Chawal)", pricePerKg = 60.0),
                    Product(name = "Sugar (Cheeni)", pricePerKg = 45.0),
                    Product(name = "Potato (Aloo)", pricePerKg = 30.0),
                    Product(name = "Onion (Pyaz)", pricePerKg = 40.0),
                    Product(name = "Toor Dal", pricePerKg = 160.0),
                    Product(name = "Wheat Flour (Atta)", pricePerKg = 42.0)
                )
                defaultProducts.forEach { repository.insertProduct(it) }
            }
        }
    }

    fun selectProduct(product: Product) {
        selectedProductId.value = product.id
    }

    fun onMoneyInputChanged(value: String) {
        // Allow numbers and single decimal point
        val filtered = value.filter { it.isDigit() || it == '.' }
        if (filtered.count { it == '.' } <= 1) {
            moneyInput.value = filtered
        }
    }

    fun onWeightInputChanged(value: String) {
        // Allow numbers and single decimal point
        val filtered = value.filter { it.isDigit() || it == '.' }
        if (filtered.count { it == '.' } <= 1) {
            weightInput.value = filtered
        }
    }

    // Money to Weight calculation result: Weight (g) = (Amount × 1000) / Price per kg
    fun calculateWeightFromMoney(amountStr: String, pricePerKg: Double?): CalculationResult.WeightResult {
        if (pricePerKg == null || pricePerKg <= 0.0) {
            return CalculationResult.WeightResult.Invalid("Please select a valid product price")
        }
        val amount = amountStr.toDoubleOrNull() ?: return CalculationResult.WeightResult.Empty
        if (amount <= 0.0) return CalculationResult.WeightResult.Empty

        val weightGrams = (amount * 1000.0) / pricePerKg

        val kgPart = (weightGrams / 1000.0).toInt()
        val gPart = weightGrams % 1000.0

        val formattedGrams = decimalFormat.format(weightGrams) + " g"
        val formattedDetail = if (kgPart > 0) {
            "$kgPart kg ${decimalFormat.format(gPart)} g"
        } else {
            formattedGrams
        }

        return CalculationResult.WeightResult.Success(
            grams = weightGrams,
            formattedString = formattedGrams,
            detailedFormattedString = formattedDetail
        )
    }

    // Weight to Money calculation result: Price (₹) = (Weight × Price per kg) / 1000
    fun calculateMoneyFromWeight(weightStr: String, pricePerKg: Double?): CalculationResult.MoneyResult {
        if (pricePerKg == null || pricePerKg <= 0.0) {
            return CalculationResult.MoneyResult.Invalid("Please select a valid product price")
        }
        val weightGrams = weightStr.toDoubleOrNull() ?: return CalculationResult.MoneyResult.Empty
        if (weightGrams <= 0.0) return CalculationResult.MoneyResult.Empty

        val price = (weightGrams * pricePerKg) / 1000.0
        val formattedCurrency = "₹ " + currencyFormat.format(price)

        return CalculationResult.MoneyResult.Success(
            amount = price,
            formattedString = formattedCurrency
        )
    }

    // Dialog Actions
    fun openAddProductDialog() {
        productToEdit.value = null
        dialogNameInput.value = ""
        dialogPriceInput.value = ""
        dialogError.value = null
        showAddEditDialog.value = true
    }

    fun openEditProductDialog(product: Product) {
        productToEdit.value = product
        dialogNameInput.value = product.name
        dialogPriceInput.value = if (product.pricePerKg % 1.0 == 0.0) {
            product.pricePerKg.toInt().toString()
        } else {
            product.pricePerKg.toString()
        }
        dialogError.value = null
        showAddEditDialog.value = true
    }

    fun openDeleteProductDialog(product: Product) {
        productToDelete.value = product
        showDeleteDialog.value = true
    }

    fun dismissAddEditDialog() {
        showAddEditDialog.value = false
        productToEdit.value = null
        dialogError.value = null
    }

    fun dismissDeleteDialog() {
        showDeleteDialog.value = false
        productToDelete.value = null
    }

    // Save action for Add / Edit Product
    fun saveProduct() {
        val name = dialogNameInput.value.trim()
        val priceStr = dialogPriceInput.value.trim()

        if (name.isEmpty()) {
            dialogError.value = "Product name cannot be empty"
            return
        }

        val price = priceStr.toDoubleOrNull()
        if (price == null || price <= 0.0) {
            dialogError.value = "Please enter a valid price per kg"
            return
        }

        val currentEdit = productToEdit.value
        viewModelScope.launch {
            if (currentEdit == null) {
                // Add new product
                val newProduct = Product(name = name, pricePerKg = price)
                val newId = repository.insertProduct(newProduct)
                selectedProductId.value = newId.toInt()
            } else {
                // Edit existing product
                val updatedProduct = currentEdit.copy(name = name, pricePerKg = price)
                repository.updateProduct(updatedProduct)
                selectedProductId.value = updatedProduct.id
            }
            dismissAddEditDialog()
        }
    }

    fun confirmDeleteProduct() {
        val target = productToDelete.value ?: return
        viewModelScope.launch {
            repository.deleteProduct(target)
            if (selectedProductId.value == target.id) {
                val remaining = products.value.filter { it.id != target.id }
                selectedProductId.value = remaining.firstOrNull()?.id
            }
            dismissDeleteDialog()
        }
    }
}

sealed class CalculationResult {
    sealed class WeightResult {
        object Empty : WeightResult()
        data class Invalid(val message: String) : WeightResult()
        data class Success(
            val grams: Double,
            val formattedString: String,
            val detailedFormattedString: String
        ) : WeightResult()
    }

    sealed class MoneyResult {
        object Empty : MoneyResult()
        data class Invalid(val message: String) : MoneyResult()
        data class Success(
            val amount: Double,
            val formattedString: String
        ) : MoneyResult()
    }
}

class ShopCalculatorViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ShopCalculatorViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ShopCalculatorViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
