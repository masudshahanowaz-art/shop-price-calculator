package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AmberPrimary = Color(0xFFD97706)
val AmberOnPrimary = Color(0xFFFFFFFF)
val AmberContainer = Color(0xFFFEF3C7)
val AmberOnContainer = Color(0xFF92400E)

val TealSecondary = Color(0xFF0D9488)
val TealContainer = Color(0xFFCCFBF1)
val TealOnContainer = Color(0xFF115E59)

val EmeraldTertiary = Color(0xFF059669)
val EmeraldContainer = Color(0xFFD1FAE5)
val EmeraldOnTertiary = Color(0xFF064E3B)

val AmberDarkPrimary = Color(0xFFFBBF24)
val TealDarkSecondary = Color(0xFF2DD4BF)
val EmeraldDarkTertiary = Color(0xFF34D399)
